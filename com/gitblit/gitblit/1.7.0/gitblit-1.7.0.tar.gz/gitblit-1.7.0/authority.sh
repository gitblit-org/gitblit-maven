#!/bin/bash
java -cp gitblit.jar com.gitblit.authority.Launcher --baseFolder data
