#!/bin/bash
java -cp "gitblit.jar:ext/*" com.gitblit.GitBlitServer --baseFolder data
