#!/bin/bash
sudo cp service-centos.sh /etc/init.d/gitblit
sudo chkconfig --add gitblit
