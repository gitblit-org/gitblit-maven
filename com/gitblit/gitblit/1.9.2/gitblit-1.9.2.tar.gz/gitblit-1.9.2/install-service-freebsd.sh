#!/bin/bash
sudo cp service-freebsd.sh /usr/local/etc/rc.d/gitblit
